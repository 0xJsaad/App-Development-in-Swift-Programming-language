# Guided Light Project 

A Xcode project for an app that changes the background based on the tap of a button which uses ternary operators to function.

## Functionality

Imitates the switching of a light but uses a button as the switch, and the backgrounds indicate if the lights are on or off.

## Demonstration
![Demo](repository-assets/Guided-Light-Demo.gif)

## Project Status
Completed

## License
[MIT](LICENSE.md)
